const form = document.getElementById("task-form");
const titleInput = document.getElementById("title");
const prioritySelect = document.getElementById("priority");
const list = document.getElementById("list");
const summary = document.getElementById("summary");
const errorBox = document.getElementById("error");
const chips = document.querySelectorAll(".chip");

let tasks = [];
let filter = "all";

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || "Something went wrong.");
  }
  return res.status === 204 ? null : res.json();
}

function showError(message) {
  errorBox.textContent = message || "";
  errorBox.hidden = !message;
}

async function loadTasks() {
  try {
    tasks = await api("/api/tasks");
    showError("");
  } catch (err) {
    showError("Could not load tasks. Is the server running?");
  }
  render();
}

function render() {
  const remaining = tasks.filter((t) => !t.done).length;
  summary.textContent = tasks.length
    ? `${remaining} to do, ${tasks.length - remaining} done`
    : "No tasks yet.";

  const visible = tasks.filter((t) =>
    filter === "all" ? true : filter === "done" ? t.done : !t.done
  );

  list.innerHTML = "";

  if (!visible.length) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = tasks.length ? "Nothing in this view." : "Add your first task above.";
    list.appendChild(li);
    return;
  }

  visible.forEach((task) => {
    const li = document.createElement("li");
    li.className = `task ${task.priority}${task.done ? " done" : ""}`;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = task.done;
    checkbox.setAttribute("aria-label", `Mark "${task.title}" as done`);
    checkbox.addEventListener("change", () => update(task.id, { done: checkbox.checked }));

    const title = document.createElement("span");
    title.className = "title";
    title.textContent = task.title; // textContent keeps user input safe from XSS

    const tag = document.createElement("span");
    tag.className = "tag";
    tag.textContent = task.priority;

    const remove = document.createElement("button");
    remove.className = "remove";
    remove.textContent = "×";
    remove.setAttribute("aria-label", `Delete "${task.title}"`);
    remove.addEventListener("click", () => removeTask(task.id));

    li.append(checkbox, title, tag, remove);
    list.appendChild(li);
  });
}

async function update(id, changes) {
  try {
    const updated = await api(`/api/tasks/${id}`, { method: "PATCH", body: JSON.stringify(changes) });
    tasks = tasks.map((t) => (t.id === id ? updated : t));
    showError("");
    render();
  } catch (err) {
    showError(err.message);
  }
}

async function removeTask(id) {
  try {
    await api(`/api/tasks/${id}`, { method: "DELETE" });
    tasks = tasks.filter((t) => t.id !== id);
    showError("");
    render();
  } catch (err) {
    showError(err.message);
  }
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    const task = await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({ title: titleInput.value, priority: prioritySelect.value }),
    });
    tasks.unshift(task);
    titleInput.value = "";
    showError("");
    render();
  } catch (err) {
    showError(err.message);
  }
});

chips.forEach((chip) =>
  chip.addEventListener("click", () => {
    filter = chip.dataset.filter;
    chips.forEach((c) => c.classList.toggle("active", c === chip));
    render();
  })
);

loadTasks();
